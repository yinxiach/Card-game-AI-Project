python3 examples/run_dmc.py --env doudizhu --xpid doudizhu --cuda 0,1,2,3 --num_actor_devices 3 --training_device 3 --num_actors 8 --save_interval 30
