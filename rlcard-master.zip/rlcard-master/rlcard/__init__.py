name = "rlcard"
__version__ = "1.0.9"

from rlcard.envs import make
