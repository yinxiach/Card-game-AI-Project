from rlcard.games.bridge.game import BridgeGame as Game
